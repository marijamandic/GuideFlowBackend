﻿INSERT INTO stakeholders."Users"(
    "Id", "Username", "Password", "Role", "IsActive")
VALUES (-1, 'admin@gmail.com', 'admin', 0, true);

INSERT INTO stakeholders."Users"(
    "Id", "Username", "Password", "Role", "IsActive")
VALUES (-11, 'autor1@gmail.com', 'autor1', 1, true);
INSERT INTO stakeholders."Users"(
    "Id", "Username", "Password", "Role", "IsActive")
VALUES (-12, 'autor2@gmail.com', 'autor2', 1, true);
INSERT INTO stakeholders."Users"(
    "Id", "Username", "Password", "Role", "IsActive")
VALUES (-13, 'autor3@gmail.com', 'autor3', 1, true);

INSERT INTO stakeholders."Users"(
    "Id", "Username", "Password", "Role", "IsActive")
VALUES (-21, 'turista1@gmail.com', 'turista1', 2, true);
INSERT INTO stakeholders."Users"(
    "Id", "Username", "Password", "Role", "IsActive")
VALUES (-22, 'turista2@gmail.com', 'turista2', 2, true);
INSERT INTO stakeholders."Users"(
    "Id", "Username", "Password", "Role", "IsActive")
VALUES (-23, 'turista3@gmail.com', 'turista3', 2, true);