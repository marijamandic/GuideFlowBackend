﻿DELETE FROM stakeholders."People";
DELETE FROM stakeholders."Users";