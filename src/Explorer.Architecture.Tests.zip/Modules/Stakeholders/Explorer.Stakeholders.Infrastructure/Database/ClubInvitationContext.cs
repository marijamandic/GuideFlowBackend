﻿using Explorer.Stakeholders.Core.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Explorer.Stakeholders.Infrastructure.Database
{
    public class ClubInvitationContext : DbContext
    {
        public DbSet<ClubInvitation> ClubInvitations { get; set; }

        public ClubInvitationContext(DbContextOptions<ClubInvitationContext> options)
            : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("stakeholders");
        }

        private static void ConfigureClubInvitation(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ClubInvitation>()
                .HasKey(ci => ci.Id); 

            modelBuilder.Entity<ClubInvitation>()
                .Property(ci => ci.Status)
                .HasConversion<string>() 
                .IsRequired();

            modelBuilder.Entity<ClubInvitation>()
                .Property(ci => ci.TouristID)
                .IsRequired(); 

            modelBuilder.Entity<ClubInvitation>()
                .Property(ci => ci.ClubId)
                .IsRequired();
        }
    }
}
