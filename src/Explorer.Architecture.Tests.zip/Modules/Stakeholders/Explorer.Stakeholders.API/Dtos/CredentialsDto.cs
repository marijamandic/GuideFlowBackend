namespace Explorer.Stakeholders.API.Dtos;

public class CredentialsDto
{
    public string Username { get; set; }
    public string Password { get; set; }
}